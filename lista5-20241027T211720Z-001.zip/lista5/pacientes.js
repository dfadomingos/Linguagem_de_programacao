const prompt = require('prompt-sync')();

function cadastraPaciente(vetPacientes){
    vetPacientes.push({
        nome: prompt(`Informe o nome do paciente: `), 
        idade: Number(prompt(`Informe a idade do paciente: `)),
        peso: Number(prompt(`Informe o peso do paciente: `)),
        altura: Number(prompt(`Informe a altura do paciente: `)),
        condicao: prompt(`Informe a condição do paciente: `)
    })    
    console.log(`Paciente cadastrado com sucesso`)
}

function consultaPacientes(vetPacientes){
    console.log(`Lista de todos os pacientes`)
    for(let i=0; i<vetPacientes.length; i++){
        console.log(`Nome: ${vetPacientes[i].nome}, Idade: ${vetPacientes[i].idade}, Peso: ${vetPacientes[i].peso}, Altura: ${vetPacientes[i].altura}, Condição: ${vetPacientes[i].condicao}`)
    }
}

function pacienteMaiorRisco(vetPacientes){
    console.log(`Paciente com maior risco`)
    let objMaiorRisco = vetPacientes[0]
    for(let i=0; i<vetPacientes.length; i++){
        if(vetPacientes[i].nota > objMaiorRisco.nota){
            objMaiorRisco = vetPacientes[i]       
        }
}
console.log(objeMaiorNota)
}

function principal(){
    let pacientes = [
        {nome: "João", idade: 65, peso: 80, altura: 1.75, condicao: "grave"},
        {nome: "Maria", idade: 58, peso: 70, altura: 1.68, condicao: "moderada"},
        {nome: "Pedro", idade: 45, peso: 85, altura: 1.82, condicao: "leve"},
        {nome: "Ana", idade: 70, peso: 65, altura: 1.60, condicao: "grave"},
        {nome: "Carlos", idade: 50, peso: 90, altura: 1.78, condicao: "moderada"}
    ]
    consultaPacientes(pacientes)
}

principal()

