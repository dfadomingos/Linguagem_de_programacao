let cliente1 = {
    nome: "Paulo",
    idade: 20,
    endereco: "Franca",
    cpf: "123.456"
}
console.log(cliente1)
console.log(`Idade: ${cliente1.idade}`)

let cliente2 = {
    nome: "Pedro",
    idade: 21,
    endereco: "Ribeirão Preto",
    cpf: "456.789"
}
console.log(`Endereço: ${cliente2.endereco}`)
cliente2.idade = 20
